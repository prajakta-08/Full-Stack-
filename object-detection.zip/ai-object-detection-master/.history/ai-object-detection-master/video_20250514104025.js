let modelIsLoaded = true; // Placeholder: change based on your AI model
document.addEventListener("DOMContentLoaded", function () {
  document.getElementById("fpsValue").innerText = document.getElementById("fps").value;

  document.getElementById("ai").addEventListener("change", toggleAi);
  document.getElementById("fps").addEventListener("input", changeFps);

  const video = document.getElementById("video");
  const c1 = document.getElementById('c1');
  const ctx1 = c1.getContext('2d');
  let cameraAvailable = false;
  let aiEnabled = false;
  let fps = 1000 / 16;

  const facingMode = "environment";
  const constraints = {
    audio: false,
    video: { facingMode: facingMode }
  };

  function camera() {
    if (!cameraAvailable) {
      navigator.mediaDevices.getUserMedia(constraints).then(function (stream) {
        cameraAvailable = true;
        video.srcObject = stream;
      }).catch(function (err) {
        cameraAvailable = false;
        if (err.name === "NotAllowedError") {
          document.getElementById("loadingText").innerText = "Waiting for camera permission...";
        }
        setTimeout(camera, 1000);
      });
    }
  }

  function timerCallback() {
    if (isReady()) {
      setResolution();
      ctx1.drawImage(video, 0, 0, c1.width, c1.height);
      if (aiEnabled) {
        ai(); // AI detection logic
      }
    }
    setTimeout(timerCallback, fps);
  }

  function isReady() {
    if (modelIsLoaded && cameraAvailable) {
      document.getElementById("loadingText").style.display = "none";
      document.getElementById("ai").disabled = false;
      return true;
    }
    return false;
  }

  function setResolution() {
    if (window.screen.width < video.videoWidth) {
      c1.width = window.screen.width * 0.9;
      const factor = c1.width / video.videoWidth;
      c1.height = video.videoHeight * factor;
    } else if (window.screen.height < video.videoHeight) {
      c1.height = window.screen.height * 0.5;
      const factor = c1.height / video.videoHeight;
      c1.width = video.videoWidth * factor;
    } else {
      c1.width = video.videoWidth;
      c1.height = video.videoHeight;
    }
  }

  function toggleAi() {
    aiEnabled = document.getElementById("ai").checked;
  }

  function changeFps() {
    const val = document.getElementById("fps").value;
    fps = 1000 / val;
    document.getElementById("fpsValue").innerText = val;
  }

  function ai() {
    console.log("AI processing frame...");
    // Add object detection logic here
  }

  camera();
  timerCallback();
});
