const video = document.getElementById("video");
const canvas = document.getElementById("c1");
const ctx = canvas.getContext("2d");
const aiToggle = document.getElementById("ai");
const fpsSlider = document.getElementById("fps");
const objectList = document.getElementById("objectList");

let aiEnabled = false;
let fps = 1000 / 16;
let model;
let modelIsLoaded = false;
let cameraAvailable = false;

// Useful object messages
const usefulMessages = {
  "person": "Someone is here.",
  "bottle": "Stay hydrated.",
  "chair": "Take a seat.",
  "book": "Read and learn.",
  "laptop": "Ready for work.",
  "cell phone": "Stay connected.",
  "keyboard": "Time to type.",
  "tv": "Relax with some shows.",
  "refrigerator": "Food is cool inside."
};

// Handle AI toggle and FPS change
aiToggle.addEventListener("change", () => {
  aiEnabled = aiToggle.checked;
});
fpsSlider.addEventListener("input", () => {
  fps = 1000 / parseInt(fpsSlider.value);
});

// Speak useful object
function speakObject(name) {
  const msg = usefulMessages[name.toLowerCase()];
  if (msg) {
    const utter = new SpeechSynthesisUtterance(msg);
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utter);
  }
}

// Camera access
const constraints = {
  video: { facingMode: "environment" },
  audio: false
};

function startCamera() {
  navigator.mediaDevices.getUserMedia(constraints)
    .then(stream => {
      video.srcObject = stream;
      cameraAvailable = true;
    })
    .catch(err => {
      cameraAvailable = false;
      document.getElementById("loadingText").innerText =
        "Camera access denied. Please allow permission.";
      setTimeout(startCamera, 1000); // retry
    });
}

// Load the model and begin
window.onload = () => {
  startCamera();
  cocoSsd.load().then(loadedModel => {
    model = loadedModel;
    modelIsLoaded = true;
    document.getElementById("loadingText").style.display = "none";
    loop(); // start detection loop
  });
};

// Resize canvas to match video size
function adjustCanvasSize() {
  if (video.videoWidth && video.videoHeight) {
    if (window.innerWidth < video.videoWidth) {
      canvas.width = window.innerWidth * 0.95;
      const scale = canvas.width / video.videoWidth;
      canvas.height = video.videoHeight * scale;
    } else {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
    }
  }
}

// Detection and drawing
async function detectObjects() {
  const predictions = await model.detect(video);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  objectList.innerHTML = "";

  predictions.forEach(pred => {
    const name = pred.class;
    const isUseful = name.toLowerCase() in usefulMessages;

    // Draw bounding box
    ctx.beginPath();
    ctx.rect(...pred.bbox);
    ctx.lineWidth = 2;
    ctx.strokeStyle = isUseful ? "green" : "red";
    ctx.stroke();

    // Label
    const label = `${name} (${isUseful ? "Useful" : "Not Useful"})`;
    const [x, y] = [pred.bbox[0], pred.bbox[1]];
    ctx.font = "bold 16px Arial";
    const textWidth = ctx.measureText(label).width;
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.fillRect(x, y > 20 ? y - 25 : y + 5, textWidth + 6, 22);
    ctx.fillStyle = isUseful ? "lime" : "red";
    ctx.fillText(label, x + 3, y > 20 ? y - 7 : y + 20);

    // Display below canvas
    const li = document.createElement("li");
    li.textContent = label;
    li.style.color = isUseful ? "green" : "red";
    objectList.appendChild(li);

    // Speak
    if (isUseful) speakObject(name);
  });
}

// Main loop
function loop() {
  if (modelIsLoaded && cameraAvailable) {
    adjustCanvasSize();
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    if (aiEnabled) detectObjects();
  }
  setTimeout(loop, fps);
}
