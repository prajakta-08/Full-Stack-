<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Object Detection</title>
  <style>
    body { font-family: Arial; text-align: center; padding: 20px; }
    video, canvas { border: 1px solid #333; margin-top: 10px; }
  </style>
</head>
<body>
  <h2>Object Detection</h2>
  <p id="loadingText">Loading camera and model...</p>
  
  <label><input type="checkbox" id="ai"> Enable AI</label>
  <br><br>
  <label>FPS: <input type="range" id="fps" min="1" max="60" value="16" /></label>
  <span id="fpsValue">16</span> FPS

  <br><br>
  <video id="video" autoplay playsinline></video>
  <canvas id="c1"></canvas>

  <script>
    let modelIsLoaded = true; // Placeholder: set to true for testing
    document.getElementById("fpsValue").innerText = document.getElementById("fps").value;

    document.getElementById("ai").addEventListener("change", toggleAi);
    document.getElementById("fps").addEventListener("input", changeFps);

    const video = document.getElementById("video");
    const c1 = document.getElementById('c1');
    const ctx1 = c1.getContext('2d');
    var cameraAvailable = false;
    var aiEnabled = false;
    var fps = 1000 / 16;

    var facingMode = "environment";
    var constraints = {
      audio: false,
      video: { facingMode: facingMode }
    };

    function camera() {
      if (!cameraAvailable) {
        navigator.mediaDevices.getUserMedia(constraints).then(function (stream) {
          cameraAvailable = true;
          video.srcObject = stream;
        }).catch(function (err) {
          cameraAvailable = false;
          if (err.name === "NotAllowedError") {
            document.getElementById("loadingText").innerText = "Waiting for camera permission...";
          }
          setTimeout(camera, 1000);
        });
      }
    }

    function timerCallback() {
      if (isReady()) {
        setResolution();
        ctx1.drawImage(video, 0, 0, c1.width, c1.height);
        if (aiEnabled) {
          ai(); // Placeholder function
        }
      }
      setTimeout(timerCallback, fps);
    }

    function isReady() {
      if (modelIsLoaded && cameraAvailable) {
        document.getElementById("loadingText").style.display = "none";
        document.getElementById("ai").disabled = false;
        return true;
      } else {
        return false;
      }
    }

    function setResolution() {
      if (window.screen.width < video.videoWidth) {
        c1.width = window.screen.width * 0.9;
        let factor = c1.width / video.videoWidth;
        c1.height = video.videoHeight * factor;
      } else if (window.screen.height < video.videoHeight) {
        c1.height = window.screen.height * 0.50;
        let factor = c1.height / video.videoHeight;
        c1.width = video.videoWidth * factor;
      } else {
        c1.width = video.videoWidth;
        c1.height = video.videoHeight;
      }
    }

    function toggleAi() {
      aiEnabled = document.getElementById("ai").checked;
    }

    function changeFps() {
      const val = document.getElementById("fps").value;
      fps = 1000 / val;
      document.getElementById("fpsValue").innerText = val;
    }

    function ai() {
      // Placeholder for AI logic, e.g., object detection
      console.log("Running AI on current frame...");
    }

    window.onload = () => {
      camera();
      timerCallback();
    };
  </script>
</body>
</html>
