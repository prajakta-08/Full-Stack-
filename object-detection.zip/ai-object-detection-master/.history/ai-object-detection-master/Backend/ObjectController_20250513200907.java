// DetectedObject.java
package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class DetectedObject {
    @Id
    @GeneratedValue
    private Long id;

    private String objectName;
    private boolean isUseful;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getObjectName() {
        return objectName;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

    public boolean isUseful() {
        return isUseful;
    }

    public void setUseful(boolean isUseful) {
        this.isUseful = isUseful;
    }
}
