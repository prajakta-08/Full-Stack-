package com.example.objectdetection.controller;

import com.example.objectdetection.service.ObjectDetectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/ai")
public class ObjectDetectionController {

    @Autowired
    private ObjectDetectionService objectDetectionService;

    // Endpoint to handle image upload for object detection
    @PostMapping("/detect")
    public String detectObjects(@RequestParam("file") MultipartFile file) {
        try {
            return objectDetectionService.detectObjects(file);
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
}

