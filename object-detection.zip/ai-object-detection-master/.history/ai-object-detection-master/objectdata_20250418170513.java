package aiobjectdetectionmaster;

public class objectdata {
    public String label;
    public float confidence;
    public int x;
    public int y;
    public int width;
    public int height;

    // Optional: Add toString() for logging/debugging
    @Override
    public String toString() {
        return "ObjectData{" +
                "label='" + label + '\'' +
                ", confidence=" + confidence +
                ", x=" + x +
                ", y=" + y +
                ", width=" + width +
                ", height=" + height +
                '}';
    }
}
