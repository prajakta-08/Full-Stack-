document.getElementById("ai").addEventListener("change", toggleAi);
document.getElementById("fps").addEventListener("input", changeFps);

const video = document.getElementById("video");
const c1 = document.getElementById("c1");
const ctx1 = c1.getContext("2d");
let cameraAvailable = false;
let aiEnabled = false;
let fps = 1000 / 16;
let model;
let modelIsLoaded = false;

const usefulMessages = {
  "bottle": "Stay hydrated.",
  "person": "Someone is here.",
  "chair": "Take a seat.",
  "book": "Read and learn.",
  "laptop": "Ready for work.",
  "cell phone": "Stay connected.",
  "keyboard": "Time to type.",
  "tv": "Relax with some shows.",
  "refrigerator": "Food is cool inside."
};

const constraints = {
  audio: false,
  video: { facingMode: "environment" }
};

function speakObject(name) {
  const msg = usefulMessages[name.toLowerCase()];
  if (msg) {
    const utter = new SpeechSynthesisUtterance(msg);
    window.speechSynthesis.speak(utter);
  }
}

function camera() {
  if (!cameraAvailable) {
    navigator.mediaDevices.getUserMedia(constraints).then(stream => {
      cameraAvailable = true;
      video.srcObject = stream;
    }).catch(err => {
      cameraAvailable = false;
      if (modelIsLoaded && err.name === "NotAllowedError") {
        document.getElementById("loadingText").innerText = "Waiting for camera permission";
      }
      setTimeout(camera, 1000);
    });
  }
}

window.onload = () => {
  camera();
  cocoSsd.load().then(loadedModel => {
    model = loadedModel;
    modelIsLoaded = true;
    document.getElementById("loadingText").style.display = "none";
  });
  timerCallback();
};

function timerCallback() {
  if (isReady()) {
    setResolution();
    ctx1.drawImage(video, 0, 0, c1.width, c1.height);
    if (aiEnabled) ai();
  }
  setTimeout(timerCallback, fps);
}

function isReady() {
  return modelIsLoaded && cameraAvailable;
}

function setResolution() {
  if (video.videoWidth && video.videoHeight) {
    if (window.screen.width < video.videoWidth) {
      c1.width = window.screen.width * 0.9;
      const factor = c1.width / video.videoWidth;
      c1.height = video.videoHeight * factor;
    } else {
      c1.width = video.videoWidth;
      c1.height = video.videoHeight;
    }
  }
}

function toggleAi() {
  aiEnabled = document.getElementById("ai").checked;
}

function changeFps() {
  fps = 1000 / document.getElementById("fps").value;
}

async function ai() {
  const predictions = await model.detect(video);
  predictions.forEach(pred => {
    const name = pred.class;
    const isUseful = name.toLowerCase() in usefulMessages;

    // Draw box
    ctx1.beginPath();
    ctx1.rect(...pred.bbox);
    ctx1.lineWidth = 2;
    ctx1.strokeStyle = isUseful ? "green" : "red";
    ctx1.stroke();

    // Draw label
    ctx1.fillStyle = isUseful ? "green" : "red";
    ctx1.font = "16px Arial";
    ctx1.fillText(`${name} (${isUseful ? "Useful" : "Not Useful"})`, pred.bbox[0], pred.bbox[1] > 10 ? pred.bbox[1] - 5 : 10);

    // Voice
    speakObject(name);
  });
}
