document.getElementById("ai").addEventListener("change", toggleAi);
document.getElementById("fps").addEventListener("input", changeFps);

const video = document.getElementById("video");
const c1 = document.getElementById('c1');
const ctx1 = c1.getContext('2d');
let cameraAvailable = false;
let aiEnabled = false;
let fps = 16;

let model;
let modelIsLoaded = false;

const facingMode = "environment";
const constraints = {
    audio: false,
    video: {
        facingMode: facingMode
    }
};

camera();

function camera() {
    if (!cameraAvailable) {
        navigator.mediaDevices.getUserMedia(constraints).then(stream => {
            cameraAvailable = true;
            video.srcObject = stream;
        }).catch(err => {
            cameraAvailable = false;
            if (modelIsLoaded && err.name === "NotAllowedError") {
                document.getElementById("loadingText").innerText = "Waiting for camera permission";
            }
            setTimeout(camera, 1000);
        });
    }
}

window.onload = function () {
    document.getElementById("ai").addEventListener("change", toggleAi);
    document.getElementById("fps").addEventListener("input", changeFps);

    camera();

    cocoSsd.load().then(loadedModel => {
        model = loadedModel;
        modelIsLoaded = true;
        console.log("Model loaded.");
    });

    timerCallback();
};


function timerCallback() {
    if (isReady()) {
        setResolution();
        ctx1.drawImage(video, 0, 0, c1.width, c1.height);
        if (aiEnabled) {
            ai();
        }
    }
    setTimeout(timerCallback, fps);
}

function isReady() {
    if (modelIsLoaded && cameraAvailable) {
        document.getElementById("loadingText").style.display = "none";
        document.getElementById("ai").disabled = false;
        return true;
    }
    return false;
}

function setResolution() {
    if (window.screen.width < video.videoWidth) {
        c1.width = window.screen.width * 0.9;
        const factor = c1.width / video.videoWidth;
        c1.height = video.videoHeight * factor;
    } else if (window.screen.height < video.videoHeight) {
        c1.height = window.screen.height * 0.5;
        const factor = c1.height / video.videoHeight;
        c1.width = video.videoWidth * factor;
    } else {
        c1.width = video.videoWidth;
        c1.height = video.videoHeight;
    }
}

function toggleAi() {
    aiEnabled = document.getElementById("ai").checked;
}

function changeFps() {
    fps = 1000 / document.getElementById("fps").value;
}

async function ai() {
    const predictions = await model.detect(video);
    predictions.forEach(object => {
        const name = object.class || object.label;
        ctx1.beginPath();
        ctx1.rect(...object.bbox);
        ctx1.lineWidth = 2;
        ctx1.strokeStyle = "red";
        ctx1.fillStyle = "red";
        ctx1.stroke();
        ctx1.fillText(name, object.bbox[0], object.bbox[1] > 10 ? object.bbox[1] - 5 : 10);
    });
}
