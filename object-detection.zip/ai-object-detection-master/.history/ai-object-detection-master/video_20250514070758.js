document.getElementById("ai").addEventListener("change", toggleAi);
document.getElementById("fps").addEventListener("input", changeFps);

const video = document.getElementById("video");
const c1 = document.getElementById("c1");
const ctx1 = c1.getContext("2d");

let cameraAvailable = false;
let aiEnabled = false;
let fps = 1000 / 16; // milliseconds
let model;
let modelIsLoaded = false;

const usefulMessages = {
    "bottle": "Stay hydrated.",
    "person": "Someone is here.",
    "chair": "Take a seat.",
    "book": "Read and learn.",
    "laptop": "Ready for work.",
    "cell phone": "Stay connected.",
    "keyboard": "Time to type.",
    "tv": "Relax with some shows.",
    "refrigerator": "Food is cool inside."
};

// Load model when page starts
window.onload = () => {
    camera();
    cocoSsd.load().then(loadedModel => {
        model = loadedModel;
        modelIsLoaded = true;
        document.getElementById("loadingText").style.display = "none";
    });
    timerCallback();
};

// Camera setup
const constraints = {
    audio: false,
    video: { facingMode: "environment" }
};

function camera() {
    if (!cameraAvailable) {
        navigator.mediaDevices.getUserMedia(constraints).then(stream => {
            cameraAvailable = true;
            video.srcObject = stream;
        }).catch(err => {
            cameraAvailable = false;
            if (modelIsLoaded && err.name === "NotAllowedError") {
                document.getElementById("loadingText").innerText = "Waiting for camera permission";
            }
            setTimeout(camera, 1000);
        });
    }
}

function timerCallback() {
    if (isReady()) {
        setResolution();
        ctx1.drawImage(video, 0, 0, c1.width, c1.height);
        if (aiEnabled) ai();
    }
    setTimeout(timerCallback, fps);
}

function isReady() {
    return modelIsLoaded && cameraAvailable;
}

function setResolution() {
    if (video.videoWidth && video.videoHeight) {
        if (window.screen.width < video.videoWidth) {
            c1.width = window.screen.width * 0.9;
            const factor = c1.width / video.videoWidth;
            c1.height = video.videoHeight * factor;
        } else {
            c1.width = video.videoWidth;
            c1.height = video.videoHeight;
        }
    }
}

function toggleAi() {
    aiEnabled = document.getElementById("ai").checked;
}

function changeFps() {
    fps = 1000 / document.getElementById("fps").value;
}

function speakObject(name) {
    const msg = usefulMessages[name.toLowerCase()];
    if (msg) {
        const utter = new SpeechSynthesisUtterance(msg);
        window.speechSynthesis.cancel(); // Stop previous speech
        window.speechSynthesis.speak(utter);
    }
}

// AI detection logic
async function ai() {
    const predictions = await model.detect(video);
    predictions.forEach(pred => {
        const name = pred.class;
        const isUseful = name.toLowerCase() in usefulMessages;

        // Draw box
        ctx1.beginPath();
        ctx1.rect(...pred.bbox);
        ctx1.lineWidth = 2;
        ctx1.strokeStyle = isUseful ? "green" : "red";
        ctx1.stroke();

        // Label
        const label = `${name} (${isUseful ? "Useful" : "Not Useful"})`;
        const [x, y] = [pred.bbox[0], pred.bbox[1]];
        ctx1.font = "bold 18px Arial";
        const textWidth = ctx1.measureText(label).width;
        ctx1.fillStyle = "rgba(0,0,0,0.6)";
        ctx1.fillRect(x, y > 20 ? y - 25 : y + 5, textWidth + 6, 22);
        ctx1.fillStyle = isUseful ? "lime" : "red";
        ctx1.fillText(label, x + 3, y > 20 ? y - 7 : y + 20);

        // Voice for useful objects
        if (isUseful) speakObject(name);
    });
}
