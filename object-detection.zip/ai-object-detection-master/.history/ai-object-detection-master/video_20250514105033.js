 // Element refs
    document.getElementById("fpsValue").innerText = document.getElementById("fps").value;
    document.getElementById("ai").addEventListener("change", toggleAi);
    document.getElementById("fps").addEventListener("input", changeFps);

    const video = document.getElementById("video");
    const c1 = document.getElementById('c1');
    const ctx1 = c1.getContext('2d');

    var cameraAvailable = false;
    var aiEnabled = false;
    var fps = 1000 / 16;
    var facingMode = "environment";

    var constraints = {
      audio: false,
      video: { facingMode: facingMode }
    };

    var modelIsLoaded = false;
    let model;
    let speakDelay = false;

    // Load model
    cocoSsd.load().then(loaded => {
      model = loaded;
      modelIsLoaded = true;
      console.log("Model loaded.");
    });

    // Start camera
    function camera() {
      if (!cameraAvailable) {
        navigator.mediaDevices.getUserMedia(constraints).then(function (stream) {
          cameraAvailable = true;
          video.srcObject = stream;
        }).catch(function (err) {
          cameraAvailable = false;
          if (modelIsLoaded && err.name === "NotAllowedError") {
            document.getElementById("loadingText").innerText = "Waiting for camera permission";
          }
          setTimeout(camera, 1000);
        });
      }
    }

    window.onload = function () {
      camera();
      timerCallback();
    }

    function timerCallback() {
      if (isReady()) {
        setResolution();
        ctx1.drawImage(video, 0, 0, c1.width, c1.height);
        if (aiEnabled) ai();
      }
      setTimeout(timerCallback, fps);
    }

    function isReady() {
      if (modelIsLoaded && cameraAvailable) {
        document.getElementById("loadingText").style.display = "none";
        document.getElementById("ai").disabled = false;
        return true;
      }
      return false;
    }

    function setResolution() {
      if (window.screen.width < video.videoWidth) {
        c1.width = window.screen.width * 0.9;
        let factor = c1.width / video.videoWidth;
        c1.height = video.videoHeight * factor;
      } else if (window.screen.height < video.videoHeight) {
        c1.height = window.screen.height * 0.50;
        let factor = c1.height / video.videoHeight;
        c1.width = video.videoWidth * factor;
      } else {
        c1.width = video.videoWidth;
        c1.height = video.videoHeight;
      }
    }

    function toggleAi() {
      aiEnabled = document.getElementById("ai").checked;
    }

    function changeFps() {
      const val = document.getElementById("fps").value;
      fps = 1000 / val;
      document.getElementById("fpsValue").innerText = val;
    }

    // Voice prompts
    const speakMap = {
      person: "There is a person nearby",
      bottle: "Stay hydrated",
      chair: "You can sit here",
      cup: "That's a cup",
      dog: "A dog is nearby",
      cat: "Look! A cat",
      laptop: "A laptop is present",
      phone: "A phone is in view",
      book: "Looks like a book"
    };

    function ai() {
      if (!model) return;
      model.detect(video).then(predictions => {
        const objects = predictions.map(p => p.class);
        showDetectedObjects(objects);

        if (objects.length > 0) {
          const mainObj = objects[0];
          if (speakMap[mainObj] && !speakDelay) {
            speak(speakMap[mainObj]);
            speakDelay = true;
            setTimeout(() => { speakDelay = false; }, 3000);
          }
        }
      });
    }

    function showDetectedObjects(objects) {
      const el = document.getElementById("detectedObjects");
      if (objects.length === 0) {
        el.textContent = "No objects detected.";
      } else {
        el.textContent = "Objects Detected: " + objects.join(", ");
      }
    }

    function speak(message) {
      const utterance = new SpeechSynthesisUtterance(message);
      utterance.pitch = 1;
      utterance.rate = 1;
      window.speechSynthesis.speak(utterance);
    }
  </script>